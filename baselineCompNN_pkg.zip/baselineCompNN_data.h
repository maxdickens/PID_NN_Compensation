//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: baselineCompNN_data.h
//
// MATLAB Coder version            : 5.4
// C/C++ source code generated on  : 27-Jun-2023 10:37:56
//

#ifndef BASELINECOMPNN_DATA_H
#define BASELINECOMPNN_DATA_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

#endif
//
// File trailer for baselineCompNN_data.h
//
// [EOF]
//
