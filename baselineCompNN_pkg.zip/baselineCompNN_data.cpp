//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: baselineCompNN_data.cpp
//
// MATLAB Coder version            : 5.4
// C/C++ source code generated on  : 27-Jun-2023 10:37:56
//

// Include Files
#include "baselineCompNN_data.h"

//
// File trailer for baselineCompNN_data.cpp
//
// [EOF]
//
